This program was created by John Baden and Daniel Luna Spring 2015 using javascript, HTML5 and with the help of the webgl-utils.js and MV.js libraries. 
It has been tested on Google Chrome and Mozilla Firefox.
